package bitc.full502.board5.data.repository;

import java.time.LocalDateTime;

public interface ReplyRepository {

}
