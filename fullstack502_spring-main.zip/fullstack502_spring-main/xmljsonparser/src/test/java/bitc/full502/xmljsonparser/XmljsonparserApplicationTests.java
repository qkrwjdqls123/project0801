package bitc.full502.xmljsonparser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XmljsonparserApplicationTests {

  @Test
  void contextLoads() {
  }

}
