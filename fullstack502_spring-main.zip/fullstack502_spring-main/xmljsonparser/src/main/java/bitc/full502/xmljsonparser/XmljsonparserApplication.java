package bitc.full502.xmljsonparser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XmljsonparserApplication {

  public static void main(String[] args) {
    SpringApplication.run(XmljsonparserApplication.class, args);
  }

}
