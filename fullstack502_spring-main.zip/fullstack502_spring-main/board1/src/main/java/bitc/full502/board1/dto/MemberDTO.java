package bitc.full502.board1.dto;

import lombok.Data;

@Data
public class MemberDTO {

  private int memberIdx;
  private String memberId;
  private String memberName;
  private int memberAge;
  private String memberEmail;
}














