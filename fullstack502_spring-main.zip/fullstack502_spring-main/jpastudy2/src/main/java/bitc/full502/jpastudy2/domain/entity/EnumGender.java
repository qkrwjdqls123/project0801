package bitc.full502.jpastudy2.domain.entity;

public enum EnumGender {
  M,
  F
}
