package bitc.full502.jpastudy2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jpastudy2ApplicationTests {

  @Test
  void contextLoads() {
  }

}
