package bitc.full502.outsidedir;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OutsideDirApplication {

  public static void main(String[] args) {
    SpringApplication.run(OutsideDirApplication.class, args);
  }

}
