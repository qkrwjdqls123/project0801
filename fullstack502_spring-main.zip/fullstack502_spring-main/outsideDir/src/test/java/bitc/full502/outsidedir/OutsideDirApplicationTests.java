package bitc.full502.outsidedir;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OutsideDirApplicationTests {

  @Test
  void contextLoads() {
  }

}
