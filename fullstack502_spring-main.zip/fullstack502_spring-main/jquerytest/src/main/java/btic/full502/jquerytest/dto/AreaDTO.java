package btic.full502.jquerytest.dto;

import lombok.Data;

@Data
public class AreaDTO {
  private String areaName;
}














