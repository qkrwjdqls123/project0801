package btic.full502.jquerytest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JquerytestApplication {

  public static void main(String[] args) {
    SpringApplication.run(JquerytestApplication.class, args);
  }

}
