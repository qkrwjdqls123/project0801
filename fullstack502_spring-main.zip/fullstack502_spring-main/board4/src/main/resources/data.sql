insert into t_jpa_board (title, contents, create_id, create_date, hit_cnt)
values ('더미 데이터 제목 1', '더미 데이터 내용 1', 'test1', now(), 0),
       ('더미 데이터 제목 2', '더미 데이터 내용 2', 'test1', now(), 0),
       ('더미 데이터 제목 3', '더미 데이터 내용 3', 'test2', now(), 0),
       ('더미 데이터 제목 4', '더미 데이터 내용 4', 'test3', now(), 0),
       ('더미 데이터 제목 5', '더미 데이터 내용 5', 'test3', now(), 0);