package bitc.full502.jpastudy.domain.repository;

import bitc.full502.jpastudy.domain.entity.JpaReplyEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JpaReplyRepository extends JpaRepository<JpaReplyEntity, Integer> {
}
