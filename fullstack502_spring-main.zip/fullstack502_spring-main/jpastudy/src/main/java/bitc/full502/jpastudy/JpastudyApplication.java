package bitc.full502.jpastudy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpastudyApplication {

  public static void main(String[] args) {
    SpringApplication.run(JpastudyApplication.class, args);
  }

}
