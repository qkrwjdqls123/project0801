package bitc.full502.jpastudy.domain.repository;

import bitc.full502.jpastudy.domain.entity.JpaProductDetailEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JpaProductDetailRepository extends JpaRepository<JpaProductDetailEntity, Integer> {
}
