package com.example.project.controller;

import com.example.project.domain.entity.BoardEntity;
import com.example.project.domain.entity.UserEntity;
import com.example.project.domain.repository.BoardRepository;
import com.example.project.domain.repository.UserRepository;
import com.example.project.service.BoardService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Controller
@RequiredArgsConstructor
public class BoardController {

    private final BoardService boardService;
    private final BoardRepository boardRepository;
    private final UserRepository userRepository;

    @Value("${file.upload-dir}")
    private String uploadDir;

    @GetMapping("/main")
    public String showMainPage(@RequestParam(required = false) String keyword, Model model) {
        List<BoardEntity> boardList;

        if (keyword != null && !keyword.isBlank()) {
            boardList = boardService.searchByTitle(keyword);
        } else {
            boardList = boardService.getBoardList();
        }

        model.addAttribute("boardList", boardList);
        model.addAttribute("keyword", keyword);

        return "main";
    }

    @GetMapping("/board")
    public String showWriteForm(@ModelAttribute BoardEntity board, HttpSession session, Model model) {

        model.addAttribute("board", new BoardEntity());
        Object loginUser = session.getAttribute("loginUser");
        board.setCreateId("loginUser");
        board.setCreateDate(LocalDateTime.now());
        boardRepository.save(board);
        if (loginUser != null) {
            return "boardWrite";
        }
        else {
            model.addAttribute("error", "로그인 후 이용 가능한 서비스입니다.");
            return "redirect:/login";
        }

    }

    @PostMapping("/board")
    public String saveBoard(@ModelAttribute BoardEntity board,
                            @RequestParam("file") MultipartFile file) throws IOException {

        if (!file.isEmpty()) {
            String uuid = UUID.randomUUID().toString();
            String fileName = uuid + "_" + file.getOriginalFilename();

            Path filePath = Paths.get(uploadDir, fileName);
            Files.createDirectories(filePath.getParent());
            Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

            board.setImageName(fileName);
        }

        board.setCreateDate(LocalDateTime.now());
        board.setHitCnt(0);

        boardRepository.save(board);
        return "redirect:/main";
    }

    @GetMapping("/board/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        BoardEntity board = boardRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("해당 게시글이 없습니다: " + id));
        model.addAttribute("board", board);
        return "boardEdit";
    }

    @PostMapping("/board/edit")
    public String updateBoard(@ModelAttribute BoardEntity board) {
        BoardEntity existing = boardRepository.findById(Long.valueOf(board.getBoardIdx()))
                .orElseThrow(() -> new IllegalArgumentException("해당 게시글이 없습니다: " + board.getBoardIdx()));

        existing.setTitle(board.getTitle());
        existing.setContents(board.getContents());
        existing.setPrice(board.getPrice());
        existing.setUpdateDate(LocalDateTime.now());

        boardRepository.save(existing);
        return "redirect:/main";
    }

    @GetMapping("/board/delete/{id}")
    public String deleteBoard(@PathVariable Long id) {
        boardRepository.deleteById(id);
        return "redirect:/main";
    }

}
