package com.example.project.controller;

import com.example.project.domain.entity.UserEntity;
import com.example.project.domain.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
public class JoinController {

    private final UserRepository userRepository;

    @GetMapping("/join.do")
    public String showJoinForm() {
        return "join";
    }

    @PostMapping("/join.do")
    public String processJoin(@RequestParam(value = "userId", required = false) String userId,
                              @RequestParam(value = "userPw", required = false) String userPw,
                              Model model) {

        if (userRepository.findByUserId(userId).isPresent()) {
            model.addAttribute("error", "이미 사용 중인 아이디입니다.");
            return "join";
        }

        UserEntity newUser = new UserEntity();
        newUser.setUserId(userId);
        newUser.setUserPw(userPw); // 평문 비밀번호

        userRepository.save(newUser);
        return "redirect:/login";
    }
}
