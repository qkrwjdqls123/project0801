package com.example.project.controller;

import com.example.project.domain.entity.UserEntity;
import com.example.project.domain.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
public class LoginController {

    private final UserRepository userRepository;

    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

    @PostMapping("/login")
    public String processLogin(@RequestParam(value = "userId", required = false) String userId,
                               @RequestParam(value = "userPw", required = false) String userPw,
                               HttpSession session,
                               Model model) {
        UserEntity user = userRepository.findByUserId(userId).orElse(null);

        if (user == null || !user.getUserPw().equals(userPw)) {
            model.addAttribute("loginError", "아이디 또는 비밀번호가 잘못되었습니다.");
            return "login";
        }

        session.setAttribute("loginUser", user.getUserId());
        return "redirect:/main";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/main";
    }
}
