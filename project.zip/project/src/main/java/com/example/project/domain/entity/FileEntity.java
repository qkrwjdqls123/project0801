package com.example.project.domain.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

//@Entity
//@Table(name = "img")
//@Getter
//@Setter
//@NoArgsConstructor
//@AllArgsConstructor
public class FileEntity {

//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @Column(nullable = false)
//    private int fileIdx;
//
//    @Column(nullable = false)
//    private int boardIdx;
//
//    @Column(nullable = false)
//    private String originalFileName;
//
//    @Column(nullable = false)
//    private String storedFileName;
//
//    @Column(nullable = false)
//    private long fileSize;
//
//    @Column(nullable = false)
//    private String createId;
//
//    @Column(nullable = false)
//    private String createDate;
//
//    @Column
//    private String updateDate;
}
