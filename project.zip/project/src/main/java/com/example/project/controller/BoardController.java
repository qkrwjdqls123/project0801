package com.example.project.controller;

public class BoardController {
}
