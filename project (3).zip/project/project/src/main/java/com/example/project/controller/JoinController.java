package com.example.project.controller;

import com.example.project.domain.entity.UserEntity;
import com.example.project.domain.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
public class JoinController {

    private final UserRepository userRepository;

    @GetMapping("/join.do")
    public String showJoinForm() {
        return "join";
    }

    @PostMapping("/join.do")
    public String processJoin(@RequestParam String UserId,
                              @RequestParam String UserPw,
                              Model model) {

        if (userRepository.findByUserId(UserId).isPresent()) {
            model.addAttribute("error", "이미 사용 중인 아이디입니다.");
            return "join";
        }

        UserEntity newUser = new UserEntity();
        newUser.setUserId(UserId);
        newUser.setUserPw(UserPw); // 평문 비밀번호

        userRepository.save(newUser);
        return "redirect:/login";
    }
}
